<div class="clearfix"></div>
</div>

<div class="grid_14" id="footer">
	<span class="footleft"><a href="<?php $this->options->siteurl(); ?>"><?php $this->options->title(); ?></a> <?php _e('is powered by'); ?> <a href="http://www.typecho.org">Typecho)))</a> and <a href="http://www.m4go.com">M4GO</a><!--这个模板是M4制作的，如果您为了页面美观，而删除本人链接。希望您能在友情链接处添加一下，谢谢！！--></span><span class="footright"><a href="<?php $this->options->feedUrl(); ?>"><?php _e('文章'); ?> RSS</a> and <a href="<?php $this->options->commentsFeedUrl(); ?>"><?php _e('评论'); ?> RSS</a></span>
</div><!-- end #footer -->

</div><!--endm4gomain-->

</div><!--endm4gobody-->
<?php $this->footer(); ?>
</body>
</html>
